# Azure SQL DB Import Data Samples

<a name="1.0.0"></a>
## 1.0.0 (2021-01-05)

First Release